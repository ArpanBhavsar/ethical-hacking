Ethical Hacking (ETH-201) — Week 5 Lab Assets
System Hacking: Evasion & Gaining Access (CEH)
Focus College · Fall 2026 · Instructor: Arpan Bhavsar · Client: CyberCorp Enterprise (fictional)

HOW TO USE
  Unzip this so that a folder named lab-assets/ sits next to week5-lab.html,
  so paths like lab-assets/shadow.txt resolve from the workbook.

PRIMARY TARGET
  Live Metasploitable 2 + a Kali attacker on a HOST-ONLY network, never bridged.
  Everything else here is a clearly-labelled FALLBACK ONLY for students with no VM
  (e.g. Apple silicon). Your Project Phase 3a evidence must come from your own runs
  where possible; say so if you used a fallback.

FILES (student zip)
  shadow.txt           Six real Metasploitable 2 md5crypt ($1$) hashes. Crack with John / Hashcat -m 500.
  lab-wordlist.txt     Small lab wordlist that contains the weak lab passwords (in class, use rockyou.txt).
  salt-demo.txt        Two accounts with the SAME password but DIFFERENT salts (Part 4 rainbow-table activity).
  sample-output/       FALLBACK transcripts (representative / verified):
                         nmap-evasion.txt   (Part 1 — four evasion scans)
                         shadow-cat.txt     (Part 2 — /etc/passwd, /etc/shadow, SUID)
                         passwd-ls.txt      (Part 2 — the SUID bit)
                         john-crack.txt     (Part 4 — cracking, verified recovered values)
                         vsftpd-exploit.txt (Part 5 — gaining access, CVE-2011-2523)
  templates/           phase3a-evidence-template.md  (fill this in for your Project)

FILES (instructor zip only)
  solutions/           nmap-flags-explained.txt, shadow-fields.txt, solutions_cracked.txt, activity-answers.md

ETHICS
  Host-only / lab targets only. Never a college, workplace, classmate, or any real
  network or Wi-Fi. Evasion lowers DETECTION, not the need for AUTHORIZATION — a quiet
  unauthorized scan is still illegal. Authorization (Week 1-2 scope) is what makes this legal.

VERIFIED (2026-11-01)
  - The six shadow.txt hashes are real Metasploitable 2 md5crypt hashes and were verified
    crackable against lab-wordlist.txt (msfadmin:msfadmin, user:user, postgres:postgres,
    service:service, sys:batman, klog:123456789).
  - salt-demo.txt: alice and bob both use password "password123" with different salts; the
    two hashes differ, proving salting. Verified with md5crypt (openssl passwd -1).
  - vsftpd 2.3.4 backdoor = CVE-2011-2523 (NVD CVSS 9.8); opens a root shell on TCP 6200.
  - Nmap evasion flags checked against Nmap's official documentation.
