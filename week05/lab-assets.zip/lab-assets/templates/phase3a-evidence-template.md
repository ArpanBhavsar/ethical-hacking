# Project Phase 3a — Evidence (ETH-201 Week 5)
Name: ____________________    Date: ____________________
Target: Metasploitable 2 (host-only)   Kali IP: __________   MS2 IP: __________

## 1. Evasion (Section 1)
- [ ] Baseline scan output saved: ____________
- [ ] Fragmented (-f) scan output saved: ____________
- [ ] Decoy (-D) scan output saved: ____________
- [ ] Source-port/timing scan output saved: ____________
- One sentence: what did the evasion flags change, and what stayed the same? ____________

## 2. Credential stores (Section 2)
- [ ] /etc/shadow copied to evidence folder
- Chosen hash line: ____________________________________________
- Algorithm id: ______  Salt: ______  (read from the line)

## 3. Cracking (Section 4)
- [ ] John command run: ____________________________________________
- Recovered accounts (john --show): ____________________________________________
- Why did the salt not stop John? ____________

## 4. Gaining access (Section 5)
- [ ] vsftpd module run; session opened (screenshot): ____________
- Proof of access — id: ____________  hostname: ____________  uname -a: ____________
- Vulnerability / Exploit / Session named: ____________

## Fallback used? (Y/N) If yes, which parts and why: ____________
