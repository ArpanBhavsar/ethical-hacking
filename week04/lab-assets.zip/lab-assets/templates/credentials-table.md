# Credentials carved — CyberCorp Phase 2b

| # | Source pcap / live | Filter used | Account | Secret | Protocol / path | Notes |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
