# Switch defense plan — ccx-core-sw01 VLAN 20

## First change-window item
Control:
Why first:

## Config sketch (lab-safe)
```
```

## App-layer backstop
