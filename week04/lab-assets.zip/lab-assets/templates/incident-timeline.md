# Incident timeline — incident-unknown.pcap

| Phase | Approx frames / time | What happened | Evidence (filter) |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

## One-sentence summary for SOC lead
