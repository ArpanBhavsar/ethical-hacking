ETH-201 Week 4 lab-assets — CyberCorp Enterprise (Kelowna BC)
Project Phase 2b: Sniffing / ARP MITM / credential carve / defenses

PRIMARY PATH this week is a LIVE host-only lab:
  Attacker: Kali Linux
  Target:   Metasploitable 2 (includes DVWA at http://$MS2/dvwa/), FTP (vsftpd), Telnet
  Part 2 (live ARP MITM) also needs a third victim VM (any Linux/Windows that browses MS2).
Set $MS2 to your real host-only Metasploitable 2 IP (find it with `ifconfig` on MS2,
or `nmap -sn <your-host-only-subnet>` from Kali). Scope: host-only / isolated lab only.
Capture your evidence to evidence/captures/ms2-*.pcap and hash it before reporting.

The pcaps/ folder is a FALLBACK for students who cannot run VMs (e.g. Apple silicon
without nested VMs). It is not the default path.

Unzip so this folder is named lab-assets/ next to week4-lab.html.

Contents:
  pcaps/          FALLBACK sample captures (use only if you cannot run the VMs)
  templates/      Credentials table, defense plan, incident timeline
  defenses/       Cisco-style DAI / DHCP Snooping / Port Security snippets
  sample-output/  Verified carve transcripts (for the fallback pcaps)
  solutions/      Instructor zip only — model answers (fallback incident scenario)
  make_pcaps.py   Regenerates the fallback pcaps (scapy); optional
  filters-cheatsheet.md
  roe-phase2b.md

Fallback-pcap addressing (CyberCorp VLAN 20 scenario — NOT your live lab):
  10.10.20.1   ccx-core-sw01 gateway   MAC 00-11-22-aa-bb-01
  10.10.20.10  mail01
  10.10.20.20  fs01 (FTP)
  10.10.20.30  legacy01 (HTTP/Telnet)
  10.10.20.50  Priya workstation
  10.10.20.66  Kali pentester          MAC 00-11-22-de-ad-66

In your LIVE lab the addresses and MACs are your own (e.g. MS2=192.168.56.101).
Wireshark filters use colon-separated MACs (e.g. 00:11:22:de:ad:66).
