#!/usr/bin/env python3
"""make_pcaps.py — ETH-201 Week 4 (Sniffing & L2/L3). Builds verified sample captures for the
CyberCorp Enterprise isolated lab (10.10.20.0/24, VLAN 20, Kelowna office). scapy only; no root,
no live interface. Every byte is synthetic and lab-safe. Run: python make_pcaps.py
Outputs .pcap files to pcaps/ and a verified summary to sample-output/pcap-verified.txt."""
import base64, os, sys
from scapy.all import (Ether, ARP, IP, TCP, UDP, Raw, DNS, DNSQR, DNSRR, wrpcap, rdpcap)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "pcaps"); os.makedirs(OUT, exist_ok=True)

# ---- CyberCorp isolated lab (VLAN 20) ----
GW   = ("10.10.20.1",  "00:11:22:aa:bb:01")   # ccx-core-sw01 gateway SVI
MAIL = ("10.10.20.10", "00:11:22:aa:bb:10")   # mail01
FS   = ("10.10.20.20", "00:11:22:aa:bb:20")   # fs01 (FTP)
WEB  = ("10.10.20.30", "00:11:22:aa:bb:30")   # legacy01 intranet (HTTP Basic + Telnet)
VIC  = ("10.10.20.50", "00:11:22:aa:bb:50")   # Priya Raman workstation (victim)
ATK  = ("10.10.20.66", "00:11:22:de:ad:66")   # Kali pentester (attacker)

def tcp_stream(cli, srv, sport, dport, payloads, t0=0.0, dt=0.03):
    """payloads: list of (who 'c'|'s', bytes). Returns list of packets with 3-way handshake."""
    (ci, cm), (si, sm) = cli, srv
    pk=[]; t=[t0]
    cseq=[1000]; sseq=[5000]
    def push(p):
        p.time=t[0]; t[0]+=dt; pk.append(p)
    # handshake
    push(Ether(src=cm,dst=sm)/IP(src=ci,dst=si)/TCP(sport=sport,dport=dport,flags="S",seq=cseq[0]))
    push(Ether(src=sm,dst=cm)/IP(src=si,dst=ci)/TCP(sport=dport,dport=sport,flags="SA",seq=sseq[0],ack=cseq[0]+1))
    cseq[0]+=1
    push(Ether(src=cm,dst=sm)/IP(src=ci,dst=si)/TCP(sport=sport,dport=dport,flags="A",seq=cseq[0],ack=sseq[0]+1))
    sseq[0]+=1
    for who,data in payloads:
        if who=='c':
            push(Ether(src=cm,dst=sm)/IP(src=ci,dst=si)/TCP(sport=sport,dport=dport,flags="PA",seq=cseq[0],ack=sseq[0])/Raw(load=data))
            cseq[0]+=len(data)
            push(Ether(src=sm,dst=cm)/IP(src=si,dst=ci)/TCP(sport=dport,dport=sport,flags="A",seq=sseq[0],ack=cseq[0]))
        else:
            push(Ether(src=sm,dst=cm)/IP(src=si,dst=ci)/TCP(sport=dport,dport=sport,flags="PA",seq=sseq[0],ack=cseq[0])/Raw(load=data))
            sseq[0]+=len(data)
            push(Ether(src=cm,dst=sm)/IP(src=ci,dst=si)/TCP(sport=sport,dport=dport,flags="A",seq=cseq[0],ack=sseq[0]))
    # teardown
    push(Ether(src=cm,dst=sm)/IP(src=ci,dst=si)/TCP(sport=sport,dport=dport,flags="FA",seq=cseq[0],ack=sseq[0]))
    push(Ether(src=sm,dst=cm)/IP(src=si,dst=ci)/TCP(sport=dport,dport=sport,flags="FA",seq=sseq[0],ack=cseq[0]+1))
    push(Ether(src=cm,dst=sm)/IP(src=ci,dst=si)/TCP(sport=sport,dport=dport,flags="A",seq=cseq[0]+1,ack=sseq[0]+1))
    return pk

# ---------- 1) HTTP Basic cleartext login to legacy01 intranet ----------
CREDS_HTTP=("praman","Spring2026!")
b64=base64.b64encode(f"{CREDS_HTTP[0]}:{CREDS_HTTP[1]}".encode()).decode()
http_req=(f"GET /portal/payroll/ HTTP/1.1\r\nHost: intranet.cybercorp.example\r\n"
          f"Authorization: Basic {b64}\r\nUser-Agent: Mozilla/5.0\r\nAccept: text/html\r\n\r\n").encode()
http_resp=(b"HTTP/1.1 200 OK\r\nServer: Apache-Coyote/1.1\r\nContent-Type: text/html\r\n"
           b"Content-Length: 61\r\n\r\n<html><body><h1>CyberCorp Payroll Portal</h1></body></html>")
pk1=tcp_stream((VIC[0],VIC[1]),(WEB[0],WEB[1]),49512,80,[('c',http_req),('s',http_resp)])
wrpcap(os.path.join(OUT,"cybercorp-http-login.pcap"),pk1)

# ---------- 2) FTP + Telnet cleartext logins ----------
ftp=[('s',b"220 (vsFTPd 2.3.4) fs01.cybercorp.example ready.\r\n"),
     ('c',b"USER svc_backup\r\n"),('s',b"331 Please specify the password.\r\n"),
     ('c',b"PASS Backup#2026\r\n"),('s',b"230 Login successful.\r\n"),
     ('c',b"SYST\r\n"),('s',b"215 UNIX Type: L8\r\n"),
     ('c',b"QUIT\r\n"),('s',b"221 Goodbye.\r\n")]
pk2=tcp_stream((VIC[0],VIC[1]),(FS[0],FS[1]),49520,21,ftp)
# Telnet: server prompts, client types login/password char-ish (send as lines for simplicity)
tel=[('s',b"\xff\xfd\x18\xff\xfd \xff\xfd#\xff\xfd'"),
     ('s',b"Ubuntu 8.04 legacy01\r\nlogin: "),('c',b"lfortin\r\n"),
     ('s',b"Password: "),('c',b"Fortin2026\r\n"),
     ('s',b"Last login: Sun Oct 25 10:12:03 2026\r\nlfortin@legacy01:~$ "),
     ('c',b"whoami\r\n"),('s',b"lfortin\r\n")]
pk2b=tcp_stream((VIC[0],VIC[1]),(WEB[0],WEB[1]),49521,23,tel,t0=5.0)
wrpcap(os.path.join(OUT,"cybercorp-ftp-telnet.pcap"),pk2+pk2b)

# ---------- 3) ARP poisoning MITM ----------
# Attacker sends unsolicited ARP replies: tells VIC that GW is at ATK mac, tells GW that VIC is at ATK mac.
pk3=[]; t=0.0
def ap(p): 
    global t
    p.time=t; t+=0.5; pk3.append(p)
# normal ARP who-has first
ap(Ether(src=VIC[1],dst="ff:ff:ff:ff:ff:ff")/ARP(op=1,hwsrc=VIC[1],psrc=VIC[0],pdst=GW[0]))
ap(Ether(src=GW[1],dst=VIC[1])/ARP(op=2,hwsrc=GW[1],psrc=GW[0],hwdst=VIC[1],pdst=VIC[0]))
# attacker poisons both directions (op=2 is-at, unsolicited)
for _ in range(3):
    ap(Ether(src=ATK[1],dst=VIC[1])/ARP(op=2,hwsrc=ATK[1],psrc=GW[0],hwdst=VIC[1],pdst=VIC[0]))   # GW is-at ATK (to victim)
    ap(Ether(src=ATK[1],dst=GW[1])/ARP(op=2,hwsrc=ATK[1],psrc=VIC[0],hwdst=GW[1],pdst=GW[0]))     # VIC is-at ATK (to gateway)
# now victim's HTTP to web rides through attacker (frames dst = ATK mac though IP = WEB)
mitm_req=(f"POST /portal/login HTTP/1.1\r\nHost: intranet.cybercorp.example\r\n"
          f"Content-Type: application/x-www-form-urlencoded\r\nContent-Length: 39\r\n\r\n"
          f"user=praman&password=Spring2026%21&go=1").encode()
# victim -> (attacker mac) -> web
seqc=2000; seqs=9000; sp=49530
pk3.append(Ether(src=VIC[1],dst=ATK[1])/IP(src=VIC[0],dst=WEB[0])/TCP(sport=sp,dport=80,flags="S",seq=seqc)); pk3[-1].time=t; t+=0.03
pk3.append(Ether(src=WEB[1],dst=ATK[1])/IP(src=WEB[0],dst=VIC[0])/TCP(sport=80,dport=sp,flags="SA",seq=seqs,ack=seqc+1)); pk3[-1].time=t; t+=0.03
pk3.append(Ether(src=VIC[1],dst=ATK[1])/IP(src=VIC[0],dst=WEB[0])/TCP(sport=sp,dport=80,flags="A",seq=seqc+1,ack=seqs+1)); pk3[-1].time=t; t+=0.03
pk3.append(Ether(src=VIC[1],dst=ATK[1])/IP(src=VIC[0],dst=WEB[0])/TCP(sport=sp,dport=80,flags="PA",seq=seqc+1,ack=seqs+1)/Raw(load=mitm_req)); pk3[-1].time=t; t+=0.03
wrpcap(os.path.join(OUT,"cybercorp-arp-mitm.pcap"),pk3)

# ---------- 4) DNS spoofing (on-path forged answer) ----------
pk4=[]; t=0.0
q=Ether(src=VIC[1],dst=GW[1])/IP(src=VIC[0],dst=GW[0])/UDP(sport=51000,dport=53)/DNS(id=0x1a2b,rd=1,qd=DNSQR(qname="intranet.cybercorp.example"))
q.time=t; t+=0.01; pk4.append(q)
# attacker forges a quick answer pointing to attacker IP (spoofed source = resolver GW)
fake=Ether(src=ATK[1],dst=VIC[1])/IP(src=GW[0],dst=VIC[0])/UDP(sport=53,dport=51000)/DNS(id=0x1a2b,qr=1,aa=1,rd=1,ra=1,qd=DNSQR(qname="intranet.cybercorp.example"),an=DNSRR(rrname="intranet.cybercorp.example",ttl=30,rdata=ATK[0]))
fake.time=t; t+=0.005; pk4.append(fake)
# the real (slower) answer arrives later, ignored
real=Ether(src=GW[1],dst=VIC[1])/IP(src=GW[0],dst=VIC[0])/UDP(sport=53,dport=51000)/DNS(id=0x1a2b,qr=1,aa=0,rd=1,ra=1,qd=DNSQR(qname="intranet.cybercorp.example"),an=DNSRR(rrname="intranet.cybercorp.example",ttl=300,rdata=WEB[0]))
real.time=t; t+=0.05; pk4.append(real)
wrpcap(os.path.join(OUT,"cybercorp-dns-spoof.pcap"),pk4)

# ---------- 5) Unknown incident pcap (Activity 4 / Assignment 2) ----------
inc=[]; tt=[0.0]
def add(p): p.time=tt[0]; tt[0]+=0.4; inc.append(p)
# phase 1: ARP poison
for _ in range(2):
    add(Ether(src=ATK[1],dst=VIC[1])/ARP(op=2,hwsrc=ATK[1],psrc=GW[0],hwdst=VIC[1],pdst=VIC[0]))
    add(Ether(src=ATK[1],dst=GW[1])/ARP(op=2,hwsrc=ATK[1],psrc=VIC[0],hwdst=GW[1],pdst=GW[0]))
# phase 2: victim HTTP Basic login to payroll portal (creds dwhitfield) through attacker
b64b=base64.b64encode(b"dwhitfield:W1nter!2026").decode()
req2=(f"GET /portal/payroll/export.csv HTTP/1.1\r\nHost: intranet.cybercorp.example\r\n"
      f"Authorization: Basic {b64b}\r\nUser-Agent: Mozilla/5.0\r\n\r\n").encode()
resp2=(b"HTTP/1.1 200 OK\r\nServer: Apache-Coyote/1.1\r\nContent-Type: text/csv\r\n"
       b"Content-Disposition: attachment; filename=cybercorp-payroll-2026Q1.csv\r\n"
       b"Content-Length: 118\r\n\r\n"
       b"employee,sin,salary\nDana Whitfield,000-000-001,142000\nMarcus Oyelaran,000-000-002,118500\nPriya Raman,000-000-003,121750\n")
hs=tcp_stream((VIC[0],VIC[1]),(WEB[0],WEB[1]),49544,80,[('c',req2),('s',resp2)],t0=tt[0])
for p in hs: tt[0]=p.time+0.4
inc+=hs
# phase 3: attacker FTP-exfils the file off fs01 using svc_backup creds
ftp2=[('s',b"220 (vsFTPd 2.3.4) fs01.cybercorp.example ready.\r\n"),
      ('c',b"USER svc_backup\r\n"),('s',b"331 Please specify the password.\r\n"),
      ('c',b"PASS Backup#2026\r\n"),('s',b"230 Login successful.\r\n"),
      ('c',b"TYPE I\r\n"),('s',b"200 Switching to Binary mode.\r\n"),
      ('c',b"RETR cybercorp-payroll-2026Q1.csv\r\n"),
      ('s',b"150 Opening BINARY mode data connection for cybercorp-payroll-2026Q1.csv (118 bytes).\r\n"),
      ('s',b"226 Transfer complete.\r\n"),('c',b"QUIT\r\n"),('s',b"221 Goodbye.\r\n")]
fs=tcp_stream((ATK[0],ATK[1]),(FS[0],FS[1]),50602,21,ftp2,t0=tt[0])
inc+=fs
wrpcap(os.path.join(OUT,"incident-unknown.pcap"),inc)

print("wrote pcaps:", sorted(os.listdir(OUT)))
print("HTTP creds b64:", b64, "->", base64.b64decode(b64).decode())
print("INC creds b64:", b64b, "->", base64.b64decode(b64b).decode())
