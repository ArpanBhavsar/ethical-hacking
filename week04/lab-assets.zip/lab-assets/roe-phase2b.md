# CyberCorp Phase 2b — Rules of Engagement addendum (class lab)

Primary path this week (authorized):
- Your own LIVE host-only lab: Kali (attacker) + Metasploitable 2 (target), plus an
  optional third victim VM for the full ARP MITM. Host-only / isolated vSwitch only.
- Capture to evidence/captures/ms2-*.pcap; hash before reporting.

Also authorized (fallback):
- Sample pcaps shipped in lab-assets/pcaps/ for students who cannot run VMs.
- 127.0.0.1 helpers if provided.

Out of scope:
- College LAN, workplace networks, coffee-shop Wi-Fi, random Internet hosts
- Production CyberCorp plant equipment
- Metasploit / exploitation (Week 5)
- Evasion flags -f / -D (Week 5)

Active Layer-2 techniques (arpspoof, Ettercap, Bettercap, macof, dnsspoof, DHCP
starvation) run ONLY on the isolated host-only lab. Enable IP forwarding before a dual
poison; stop immediately if a demo misbehaves; disable forwarding, let ARP/DHCP restore,
and document what happened.
