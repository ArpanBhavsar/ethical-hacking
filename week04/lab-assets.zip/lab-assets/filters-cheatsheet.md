# Wireshark display filters — ETH-201 Week 4

| Goal | Display filter |
|---|---|
| HTTP Basic | `http.authorization` |
| HTTP POST login | `http.request.method == "POST"` |
| FTP passwords | `ftp.request.command == "PASS"` |
| Telnet | `telnet` then Follow → TCP Stream |
| SNMPv1/v2c community | `snmp.community` |
| ARP replies | `arp.opcode == 2` |
| Attacker MAC | `eth.addr == 00:11:22:de:ad:66` |
| DNS for intranet | `dns.qry.name == "intranet.cybercorp.example"` |

tcpdump (capture-filter syntax on a saved file):
`tcpdump -nn -r file.pcap 'tcp port 80 or tcp port 21 or arp'`

tshark:
`tshark -r file.pcap -Y http.authorization -T fields -e http.authorization`

## Live capture on the host-only lab (primary path)

Set `MS2` to your real Metasploitable 2 host-only IP first, e.g. `export MS2=192.168.56.101`.

```
# cleartext capture (Part 1):
sudo tcpdump -i eth0 -w evidence/captures/ms2-cleartext.pcap host $MS2 and '(tcp port 21 or tcp port 23 or tcp port 80)'
# MITM capture (Part 2):
sudo tcpdump -i eth0 -w evidence/captures/ms2-mitm.pcap
# DNS capture (Part 3):
sudo tcpdump -i eth0 -w evidence/captures/ms2-dns.pcap 'udp port 53'
```

The display filters below apply to your OWN live captures as well as the fallback pcaps.
In a LIVE ARP MITM the attacker MAC is your Kali's MAC (not the fallback `00:11:22:de:ad:66`).
