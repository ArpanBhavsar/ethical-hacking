#!/usr/bin/env python3
"""cybercorp_range.py - ETH-201 Week 3 Kali-only fallback target (Focus College, Ethical Hacking).

Starts four harmless pretend CyberCorp Enterprise services on 127.0.0.1 ONLY (your own
computer). Use it when your Metasploitable 2 VM is not available. Nothing listens on a
real network interface, so you cannot disturb anyone else's network.

  python3 cybercorp_range.py           # runs until Ctrl+C (no root needed)
  nmap -sT -sV -p 9021,9022,9025,9080 127.0.0.1

Ports (all on 127.0.0.1):
  9021  FTP banner   - an old "vsFTPd 2.3.4" banner (an out-of-date daemon to flag)
  9022  SSH banner   - "OpenSSH_7.4" (old but still supported by some vendors)
  9025  SMTP         - CyberCorp mail relay that answers VRFY, EXPN and RCPT TO honestly,
                       so you can practise SMTP user enumeration
  9080  HTTP         - "CyberCorp Kelowna Intranet" served by an Apache-Coyote (Tomcat) header
"""
import socketserver, threading, http.server, sys

HOST = "127.0.0.1"
STAFF = {"dwhitfield": "Dana Whitfield", "moyelaran": "Marcus Oyelaran",
         "praman": "Priya Raman", "lfortin": "Leo Fortin", "svc_backup": "Backup service account"}
LISTS = {"it-ops": ["lfortin", "praman"], "finance": ["moyelaran"]}

class FTP(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(b"220 (vsFTPd 2.3.4)\r\n")
        for line in self.rfile:
            c = line.decode(errors="ignore").strip().upper()
            if c.startswith("USER"):
                self.wfile.write(b"331 Please specify the password.\r\n")
            elif c.startswith("PASS"):
                self.wfile.write(b"530 Login incorrect.\r\n")
            elif c.startswith("QUIT"):
                self.wfile.write(b"221 Goodbye.\r\n"); return
            else:
                self.wfile.write(b"530 Please login with USER and PASS.\r\n")

class SSH(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(b"SSH-2.0-OpenSSH_7.4\r\n")
        try:
            self.rfile.readline()
        except Exception:
            pass

class SMTP(socketserver.StreamRequestHandler):
    def say(self, s):
        self.wfile.write((s + "\r\n").encode())
    def handle(self):
        self.say("220 mail01.cybercorp.example ESMTP Postfix (CyberCorp relay)")
        for line in self.rfile:
            cmd = line.decode(errors="ignore").strip()
            up = cmd.upper()
            arg = cmd.split(" ", 1)[1].strip() if " " in cmd else ""
            if up.startswith(("EHLO", "HELO")):
                self.wfile.write(b"250-mail01.cybercorp.example\r\n250-PIPELINING\r\n250-SIZE 20480000\r\n"
                                 b"250-VRFY\r\n250-ETRN\r\n250-8BITMIME\r\n250 DSN\r\n")
            elif up.startswith("VRFY"):
                u = arg.strip("<>").split("@")[0].lower()
                if u in STAFF:
                    self.say(f"250 2.0.0 {STAFF[u]} <{u}@cybercorp.example>")
                else:
                    self.say(f"550 5.1.1 <{u}>: Recipient address rejected: User unknown in local recipient table")
            elif up.startswith("EXPN"):
                l = arg.strip("<>").lower()
                if l in LISTS:
                    m = LISTS[l]
                    for i, u in enumerate(m):
                        sep = " " if i == len(m) - 1 else "-"
                        self.say(f"250{sep}2.1.5 {STAFF[u]} <{u}@cybercorp.example>")
                else:
                    self.say("550 5.1.1 Mailing list not found")
            elif up.startswith("MAIL FROM"):
                self.say("250 2.1.0 Ok")
            elif up.startswith("RCPT TO"):
                u = arg.split(":", 1)[-1].strip().strip("<>").split("@")[0].lower()
                if u in STAFF or u in LISTS:
                    self.say("250 2.1.5 Ok")
                else:
                    self.say(f"550 5.1.1 <{u}@cybercorp.example>: Recipient address rejected: User unknown")
            elif up.startswith("RSET"):
                self.say("250 2.0.0 Ok")
            elif up.startswith("HELP"):
                self.say("214 2.0.0 Commands: EHLO HELO MAIL RCPT VRFY EXPN RSET QUIT HELP")
            elif up.startswith("QUIT"):
                self.say("221 2.0.0 Bye"); return
            else:
                self.say("502 5.5.2 Error: command not recognized")

PAGE = b"""<!doctype html><html><head><title>CyberCorp Kelowna Intranet (training)</title></head>
<body><h1>CyberCorp Enterprise - Kelowna Intranet</h1>
<p>ETH-201 Week 3 practice target. Staff portal moved to /portal/ (Tomcat 9).</p>
<!-- ops: contact it-ops@cybercorp.example; legacy build ccx-intranet-1.8 --></body></html>"""

class Web(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def version_string(self):
        return "Apache-Coyote/1.1"
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Allow", "GET, HEAD, OPTIONS")
        self.send_header("Content-Length", "0")
        self.end_headers()
    def do_HEAD(self):
        self.do_GET(head=True)
    def do_GET(self, head=False):
        if self.path == "/robots.txt":
            body, ctype = b"User-agent: *\nDisallow: /portal/admin/\nDisallow: /backup-2025/\n", "text/plain"
        else:
            body, ctype = PAGE, "text/html"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if not head:
            self.wfile.write(body)
    def log_message(self, *a):
        pass

class TS(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

def main():
    servers = [(9021, FTP, "FTP"), (9022, SSH, "SSH"), (9025, SMTP, "SMTP"), (9080, Web, "HTTP")]
    started = []
    for port, h, name in servers:
        try:
            s = (http.server.ThreadingHTTPServer if h is Web else TS)((HOST, port), h)
        except OSError as e:
            print(f"[!] could not start {name} on {HOST}:{port}: {e}")
            continue
        threading.Thread(target=s.serve_forever, daemon=True).start()
        started.append((port, name, s))
        print(f"[+] {name:4} listening on {HOST}:{port}")
    if not started:
        sys.exit(1)
    print("[*] CyberCorp practice range running on 127.0.0.1 only. Press Ctrl+C to stop.")
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        print("\n[*] stopping")
        for _, _, s in started:
            s.shutdown()

if __name__ == "__main__":
    main()
