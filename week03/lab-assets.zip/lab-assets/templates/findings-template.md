# Phase 2a findings template — CyberCorp / ETH-201 Week 3
Student name:
Path used: [ ] Metasploitable 2    [ ] Kali fallback (cybercorp_range.py / range_extras)
Nmap version (`nmap --version`):
Date (Pacific):

## Finding 1
- Host / port / protocol:
- Evidence (command + key output lines):
- CEH state / enum detail:
- Priority (High/Medium/Low) and why CyberCorp should care:

## Finding 2
- Host / port / protocol:
- Evidence:
- CEH state / enum detail:
- Priority and business impact:

## Finding 3
- Host / port / protocol:
- Evidence:
- CEH state / enum detail:
- Priority and business impact:

## Finding 4
- Host / port / protocol:
- Evidence:
- CEH state / enum detail:
- Priority and business impact:

## Finding 5
- Host / port / protocol:
- Evidence:
- CEH state / enum detail:
- Priority and business impact:
