# Assignment 1 checklist (6% · due Fri Oct 23, 2026 before midnight PT)
- [ ] Week 2 OSINT dossier summarized (who / what / where)
- [ ] Host discovery evidence saved
- [ ] TCP port + version scan with `nmap -oA ...` files attached
- [ ] At least one odd-flag or hping3 contrast documented (limitation noted)
- [ ] Safe NSE output for ≥1 service
- [ ] Enumeration for ≥2 protocols (e.g. SMTP, SNMP, DNS AXFR attempt, SMB/enum4linux)
- [ ] Five prioritized attack-surface items in business language for CyberCorp
- [ ] Tool versions, commands, timestamps recorded
- [ ] No out-of-scope hosts; fallback path named if used
