CyberCorp FS01 public share (training).
IT contact: Leo Fortin, it-ops@cybercorp.example
Old VPN guide moved to \\fs01\it$\vpn-2024.pdf
