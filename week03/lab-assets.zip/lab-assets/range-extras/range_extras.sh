#!/usr/bin/env bash
# range_extras.sh - ETH-201 Week 3 optional CyberCorp services on 127.0.0.1 (Kali fallback, Part 5).
#   ./range_extras.sh start          DNS (tcp/udp 5353), SNMP (udp 1161), LDAP (tcp 3890), no root needed
#   ./range_extras.sh start --smb    also an SMB file server on 139/445 (asks for sudo; Samba must be installed)
#   ./range_extras.sh stop           stops everything this script started
# Packages (Kali): sudo apt install bind9 snmpd slapd ldap-utils samba snmp
# Everything binds to 127.0.0.1 only and writes runtime files under ./run/ next to this script.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; RUN="$HERE/run"; mkdir -p "$RUN"
need(){ command -v "$1" >/dev/null 2>&1 || [ -x "/usr/sbin/$1" ] || { echo "[!] $1 not found - install it (see header)"; return 1; }; }
bin(){ command -v "$1" 2>/dev/null || echo "/usr/sbin/$1"; }
start_dns(){ need named || return; mkdir -p "$RUN/dns"; cp "$HERE"/db.*.example "$RUN/dns/"
  cat > "$RUN/dns/named.conf" <<CONF
options { directory "$RUN/dns"; listen-on port 5353 { 127.0.0.1; }; listen-on-v6 { none; };
  pid-file "$RUN/dns/named.pid"; recursion no; notify no; dnssec-validation no; };
zone "cybercorp.example" { type primary; file "db.cybercorp.example"; allow-transfer { none; }; };
zone "corp.cybercorp.example" { type primary; file "db.corp.cybercorp.example"; allow-transfer { any; }; };
CONF
  "$(bin named)" -c "$RUN/dns/named.conf" -p 5353 -L "$RUN/dns/named.log" && echo "[+] DNS  127.0.0.1:5353 (zones cybercorp.example, corp.cybercorp.example)"; }
start_snmp(){ need snmpd || return; mkdir -p "$RUN/snmp"
  "$(bin snmpd)" -C -c "$HERE/ccx-snmpd.conf" -p "$RUN/snmp/snmpd.pid" -Lf "$RUN/snmp/snmpd.log" udp:127.0.0.1:1161 && echo "[+] SNMP 127.0.0.1:1161/udp (community public)"; }
start_ldap(){ need slapd || return; mkdir -p "$RUN/ldap/db"
  cat > "$RUN/ldap/slapd.conf" <<CONF
include /etc/ldap/schema/core.schema
include /etc/ldap/schema/cosine.schema
include /etc/ldap/schema/inetorgperson.schema
pidfile $RUN/ldap/slapd.pid
modulepath /usr/lib/ldap
moduleload back_mdb
database mdb
suffix "dc=corp,dc=cybercorp,dc=example"
rootdn "cn=admin,dc=corp,dc=cybercorp,dc=example"
rootpw TrainingOnly-2026
directory $RUN/ldap/db
access to attrs=userPassword by self write by anonymous auth by * none
access to * by * read
CONF
  "$(bin slapd)" -f "$RUN/ldap/slapd.conf" -h "ldap://127.0.0.1:3890/" || return; sleep 1
  ldapadd -x -H ldap://127.0.0.1:3890 -D "cn=admin,dc=corp,dc=cybercorp,dc=example" -w TrainingOnly-2026 -f "$HERE/ccx-people.ldif" >/dev/null 2>&1
  echo "[+] LDAP 127.0.0.1:3890 (base dc=corp,dc=cybercorp,dc=example, anonymous read)"; }
start_smb(){ need smbd || return; mkdir -p "$RUN/smb/private"
  sed -e "s#@RUN@#$RUN#g" -e "s#@HERE@#$HERE#g" "$HERE/ccx-smb.conf.in" > "$RUN/smb/smb.conf"
  sudo "$(bin smbd)" -s "$RUN/smb/smb.conf" -D && sudo "$(bin nmbd)" -s "$RUN/smb/smb.conf" -D && echo "[+] SMB  127.0.0.1:139,445 (FS01, workgroup CYBERCORP, guest share 'public')"; }
stopall(){ for p in "$RUN"/dns/named.pid "$RUN"/ldap/slapd.pid "$RUN"/snmp/snmpd.pid; do [ -f "$p" ] && kill "$(cat "$p")" 2>/dev/null; done
  [ -f "$RUN/smb/smb.conf" ] && { sudo pkill -f "smbd -s $RUN/smb/smb.conf"; sudo pkill -f "nmbd -s $RUN/smb/smb.conf"; }
  echo "[*] stopped CyberCorp range extras"; }
case "${1:-}" in
  start) start_dns; start_snmp; start_ldap; [ "${2:-}" = "--smb" ] && start_smb; echo "[*] stop with: $0 stop";;
  stop) stopall;;
  *) sed -n '2,8p' "$0";;
esac
