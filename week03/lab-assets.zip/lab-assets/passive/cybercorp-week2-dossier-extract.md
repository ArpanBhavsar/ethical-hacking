# CyberCorp Enterprise — Week 2 dossier extract (for Week 3 Phase 2a)
Fictional client · Kelowna BC · ETH-201 Focus College · Fall 2026

## Who
- Legal name: CyberCorp Enterprise
- Leadership (public pages): Dana Whitfield (COO), Marcus Oyelaran (Finance), Priya Raman (Sysadmin), Leo Fortin (IT Operations)
- Email pattern observed: first initial + last name @ cybercorp.example (e.g. lfortin@cybercorp.example)

## What (technologies hinted passively)
- FortiClient / FortiGate VPN onboarding language on careers page
- Customer portal on Tomcat 9 + PostgreSQL 13 (job ad)
- Microsoft 365 migration; Exchange 2016 still mentioned in an old PDF
- File server UNC hint: \\fs01.corp.cybercorp.example\departments

## Where (names from CT / docs — NOT a scan licence for the real internet)
- www.cybercorp.example, portal.cybercorp.example, staging.cybercorp.example
- mail01.cybercorp.example, vpn.cybercorp.example
- fs01.corp.cybercorp.example, ns1/ns2.cybercorp.example

## Authorization for Week 3 active work
You may scan/enumerate ONLY:
1. Metasploitable 2 on your isolated lab network
2. The Kali fallback started from lab-assets/cybercorp_range.py (+ optional range_extras.sh) on 127.0.0.1
3. Light scans of scanme.nmap.org per its policy

You may NOT scan real CyberCorp-looking hosts on the public internet. The names above are fiction for dossier continuity.
