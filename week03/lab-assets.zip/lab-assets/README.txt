ETH-201 Week 3 lab-assets (student)
Unzip this archive NEXT TO week3-lab.html so that paths look like:
  ./week3-lab.html
  ./lab-assets/cybercorp_range.py
  ./lab-assets/range-extras/range_extras.sh
  ./lab-assets/wordlists/ccx-usernames.txt
  ...

Primary target: Metasploitable 2 (isolated VMware network).
Fallback: python3 lab-assets/cybercorp_range.py  (127.0.0.1 only)
Optional extras: lab-assets/range-extras/range_extras.sh start [--smb]

Do NOT scan systems outside the course authorization list.
