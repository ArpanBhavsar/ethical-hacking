#!/usr/bin/env python3
"""osint_dossier.py - ETH-201 Week 2 lab helper (Focus College, Fall 2026).

Builds a passive-footprinting dossier from LOCAL, SIMULATED CyberCorp artefacts:
robots.txt, sitemap.xml, a saved web page, a job posting and document metadata.
It never sends a packet to any target. Optional: --dorks DOMAIN prints Google dorks
for you to run BY HAND, and only against a domain you are authorized to research.

usage: python3 osint_dossier.py [--site DIR] [--docs DIR] [--dorks DOMAIN] [--out FILE]
"""
import argparse, json, os, re, shutil, subprocess, sys, xml.etree.ElementTree as ET
from collections import Counter

TECH = ["Windows Server 2019", "Active Directory", "Microsoft 365", "FortiGate", "FortiClient",
        "Exchange 2016", "Exchange Online", "Apache Tomcat 9", "PostgreSQL 13", "Veeam",
        "Cisco Meraki", "ServiceNow", "WordPress"]
SENSITIVE = ("admin", "backup", "old", "dev", "hr", "staging", "test")

def robots(path):
    dis, maps = [], []
    for line in open(path, encoding="utf-8"):
        line = line.split("#", 1)[0].strip()
        if line.lower().startswith("disallow:"):
            p = line.split(":", 1)[1].strip()
            if p: dis.append(p)
        elif line.lower().startswith("sitemap:"):
            maps.append(line.split(":", 1)[1].strip())
    return dis, maps

def sitemap(path):
    ns = {"s":
